# PhotoSwipe

App Android nativa para revisar las fotos de tu galería una por una:
- Deslizar a la **derecha** → conservar la foto (pasa a la siguiente).
- Deslizar a la **izquierda** → eliminar la foto de verdad (pide confirmación del sistema, igual que Google Fotos).

## Cómo abrir y compilar el proyecto

1. Instala [Android Studio](https://developer.android.com/studio) (gratis).
2. Abre Android Studio → **Open** → selecciona la carpeta `PhotoSwipe` (la que contiene este README).
3. Espera a que Gradle sincronice (la primera vez descarga dependencias, puede tardar unos minutos).
4. Conecta tu teléfono Android por USB con el **modo desarrollador** y la **depuración USB** activados, o usa un emulador.
5. Pulsa el botón ▶️ (Run) en Android Studio. La app se instalará en el teléfono.

### Generar el .apk para instalar manualmente
En Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
El archivo `.apk` resultante aparece en `app/build/outputs/apk/debug/app-debug.apk`. Puedes copiarlo a tu teléfono y abrirlo para instalar (necesitarás permitir "instalar apps de orígenes desconocidos" en Ajustes).

## Cómo funciona el borrado real

Android no permite que ninguna app borre fotos directamente sin confirmación del usuario (por seguridad, desde Android 10+). Por eso, al deslizar a la izquierda, el sistema operativo muestra **su propio diálogo nativo** preguntando "¿Eliminar este elemento?". Si confirmas, la foto se borra de verdad de tu galería. Si cancelas, la foto se queda donde estaba y la verás de nuevo.

## Permisos

La primera vez que abras la app, Android pedirá permiso para "Acceder a fotos y videos". Es necesario para poder listarlas. La app no sube ni envía tus fotos a ningún servidor: todo ocurre localmente en el teléfono.

## Estructura del proyecto

```
app/src/main/java/com/photoswipe/app/
├── MainActivity.kt          # Permisos + lógica de borrado del sistema
├── data/
│   ├── Photo.kt              # Modelo de datos
│   └── PhotoRepository.kt    # Lee las fotos desde MediaStore
└── ui/
    ├── PhotoSwipeScreen.kt   # Pantalla con el gesto de swipe
    └── theme/Theme.kt        # Colores y estilo
```

## Posibles mejoras futuras
- Mostrar también videos, no solo fotos.
- Botón de "deshacer" tras eliminar.
- Filtrar por álbum o por fecha.
- Modo "papelera" (mover a una carpeta temporal antes de borrar definitivamente).
